class Stuff:
    def __init__(self, id, name, isBad):
        self.id = id
        self.name = name
        self.isBad = isBad
        # isBad bool 값을 추후 랜덤으로 배정 예정