class Rack :
    def __init__(self , quantity):
        self.quantity = quantity

    def put(self):
        pass

    def get(self):
        pass
